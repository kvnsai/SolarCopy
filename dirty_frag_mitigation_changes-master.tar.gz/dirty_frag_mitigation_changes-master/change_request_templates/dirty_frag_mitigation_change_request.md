\########################################################################################################################################

**NOTE:**  Prior to any change, the customer must be made aware, provide the engineer a specific timeline and scope of nodes for mitigation.

\########################################################################################################################################

## Priority

- High (24 Hr Review): Security‑related change addressing active local privilege‑escalation vulnerabilities.


## Date
- When are you planning on making this change?

    As soon as both:
    - approval is granted (target: next working day)
    - the customer confirms we can take action according to their defined timeline.

## Reason

- Why this change needs to be made

  *   Recently disclosed Linux kernel vulnerabilities (DirtyFrag) allow unprivileged local users to gain elevated privileges.
  *   No vendor kernel patches are currently available.
  *   Mitigation is required to reduce the risk of exploitation. 

- Customer business case

  *   Protects shared compute resources from privilege escalation.
  *   Reduces risk of service disruption, data exposure, or lateral movement.
  *   Demonstrates proactive security posture while awaiting vendor fixes.

- Technical reason for implementation

  *   CVEs exploit unsafe page‑cache write behaviour in specific kernel subsystems:
      *   **CVE‑2026‑43284** - xfrm ESP page‑cache write
      *   **CVE‑2026‑43500** - RxRPC page‑cache write
  *   Mitigation restricts access to affected kernel interfaces, blocking known exploitation vectors.
  *   No kernel upgrade or reboot required.

## Process

Expected steps to perform change

**For all clusters:**

Clone / download the repo to the cluster in a sensible directory shared across all nodes.
Download from https://decapp.x-iss.com/gitlab/jmoore/dirty_frag_mitigation_changes

**For a Bright cluster:**

- Review the `change_scripts/live_nodes_change_scripts/dirty-frag-mitigation-bright.sh` script.
- Run the `change_scripts/live_nodes_change_scripts/dirty-frag-mitigation-bright.sh` script and record the output into the ticket.
- If any node has `esp` modules loaded in the kernel, investigate if these are in use / what by then discuss whether to manually apply the mitigations with a senior engineer after review.

- Review the `change_scripts/software_image_change_scripts/dirty-frag-mitigation-bright.sh` script.
- Amend the `change_scripts/software_image_change_scripts/dirty-frag-mitigation-bright.sh` script to have the correct image names within the images list.
- Run the `change_scripts/software_image_change_scripts/dirty-frag-mitigation-bright.sh` script and record the output into the ticket.


**For a Confluent cluster:**

- Review the `change_scripts/live_nodes_change_scripts/dirty-frag-mitigation-confluent.sh` script.
- Run the `change_scripts/live_nodes_change_scripts/dirty-frag-mitigation-confluent.sh` script and record the output into the ticket.
- If any node has `esp` modules loaded in the kernel, investigate if these are in use / what by then discuss whether to manually apply the mitigations with a senior engineer after review.

- Review the `change_scripts/software_image_change_scripts/dirty-frag-mitigation-confluent.sh` script.
- Amend the `change_scripts/software_image_change_scripts/dirty-frag-mitigation-confluent.sh` script to have the correct image names within the images list and ensure or amend the `97` prefix to the `firstboot.d` script such that it is reasonable and functional.
- Run the `change_scripts/software_image_change_scripts/dirty-frag-mitigation-confluent.sh` script and record the output into the ticket.

- Redeploy a test node for a single software image and validate that the mitigations have been correctly created at `/etc/modprobe.d/dirtyfrag.conf`.

### Acceptance criteria (validation plan)

Review and run the appropriate script from below for the given cluster type:
- `change_scripts/validation/dirty-frag-mitigation-bright.sh`
- `change_scripts/validation/dirty-frag-mitigation-confluent.sh` - if `97` prefix was amended, modify this check script appropriately.

**For a Confluent cluster:**
- Confirm test node has correctly created the `/etc/modprobe.d/dirtyfrag.conf` file.


## Rollback Plan

- Review the revert change script applicable for the cluster type.
- Amend the line defining the image names.
- Run the revert change script applicable for the cluster type. 

See scripts:
- `change_scripts/validation/dirty-frag-mitigation-bright.sh`
- `change_scripts/validation/dirty-frag-mitigation-confluent.sh` - if `97` prefix was amended, modify this script appropriately.



## Test Plan

To be filled when scripts validated/tested on initial clusters.

## Risk

Level of change based on above 
- H/M/L - Low


- Risk Mitigation 
  - Implementation aborts setup where usage of IPSEC is detected via `lsmod | grep -E 'esp4|esp6'`
  - Rollback scripts available.

- Candidate for Standard change? No


## Impact

of change:

- H/M/L - Low
- Outage required? - Not required.
- Impact mitigation 
  - Scripts abort mitigation where IPSEC is detected via `lsmod | grep -E 'esp4|esp6'`.


## Customer Aware: -yes/no

Prior to any change, the customer must be made aware and they must provide the engineer a specific timeline and agreed scope of nodes for mitigation.


## Linked Information

* ITGlue Change Request process: <https://xiss.itglue.com/1019631/docs/5057565>


* https://access.redhat.com/security/vulnerabilities/RHSB-2026-003
* https://access.redhat.com/security/cve/cve-2026-43284
* https://access.redhat.com/security/cve/cve-2026-43500
* https://ubuntu.com/blog/dirty-frag-linux-vulnerability-fixes-available