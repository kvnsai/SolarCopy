#!/bin/bash
## Mitigation for Dirty Frag (CVE‑2026‑43284 + CVE‑2026‑43500) on bright clusters. 
if [[ $EUID -ne 0 ]]; then
  echo "Error: This script must be run as root or with sudo." >&2
  exit 1
fi

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
REMOTE_HELPER="${SCRIPT_DIR}/../live_node_helpers/dirtyfrag_apply_mitigation.sh"

if [[ ! -f "$REMOTE_HELPER" ]]; then
  echo "Error: Helper script not found in shared directory: $REMOTE_HELPER" >&2
  exit 1
fi

pdsh -a "[ -r \"$REMOTE_HELPER\" ] && /bin/bash \"$REMOTE_HELPER\" || echo 'Missing helper script or execution failed.'" | dshbak -c
