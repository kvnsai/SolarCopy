#!/bin/bash
## Revert Dirty Frag (CVE-2024-3174) mitigation on bright clusters.

images=(bigmem-compute compute gpu-compute-nctk login)

if [[ $EUID -ne 0 ]]; then
  echo "Error: This script must be run as root or with sudo." >&2
  exit 1
fi

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
REMOTE_REVERT_HELPER="${SCRIPT_DIR}/../live_node_helpers/dirtyfrag_revert_mitigation.sh"
REMOTE_VALIDATE_HELPER="${SCRIPT_DIR}/../live_node_helpers/dirtyfrag_validate_revert.sh"

if [[ ! -f "$REMOTE_REVERT_HELPER" || ! -f "$REMOTE_VALIDATE_HELPER" ]]; then
  echo "Error: One or more helper scripts are missing in live_node_helpers directory." >&2
  exit 1
fi

# Remove mitigation from each software image.
for image_name in "${images[@]}"; do
  rm -f "/cm/images/${image_name}/etc/modprobe.d/dirtyfrag.conf"
done

# Remove mitigation drop-in on live nodes if it exists.
pdsh -a "[ -r $REMOTE_REVERT_HELPER ] && /bin/bash $REMOTE_REVERT_HELPER || echo 'Missing shared helper script or execution failed.'" | dshbak -c

# Validation on images
for image_name in "${images[@]}"; do
  image_conf="/cm/images/${image_name}/etc/modprobe.d/dirtyfrag.conf"
  if [ -f "$image_conf" ]; then
    echo "${image_name}: dirtyfrag.conf is still present"
  else
    echo "${image_name}: mitigation config removed"
  fi
done

# Validation on live nodes
pdsh -a "[ -r $REMOTE_VALIDATE_HELPER ] && /bin/bash $REMOTE_VALIDATE_HELPER || echo 'Missing shared helper script or execution failed.'" | dshbak -c

