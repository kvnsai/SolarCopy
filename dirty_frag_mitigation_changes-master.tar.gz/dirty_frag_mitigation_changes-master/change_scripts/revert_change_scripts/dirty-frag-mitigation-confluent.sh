#!/bin/bash
## Revert Dirty Frag (CVE‑2026‑43284 + CVE‑2026‑43500) mitigation on confluent clusters. 

images=(rhel-9.6-x86_64-compute  rhel-9.6-x86_64-login rhel-9.6-x86_64-default )

if [[ $EUID -ne 0 ]]; then
  echo "Error: This script must be run as root or with sudo." >&2
  exit 1
fi

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
REMOTE_REVERT_HELPER="${SCRIPT_DIR}/../live_node_helpers/dirtyfrag_revert_mitigation.sh"
REMOTE_VALIDATE_HELPER="${SCRIPT_DIR}/../live_node_helpers/dirtyfrag_validate_revert.sh"

if [[ ! -f "$REMOTE_REVERT_HELPER" || ! -f "$REMOTE_VALIDATE_HELPER" ]]; then
  echo "Error: One or more helper scripts are missing in live_node_helpers directory." >&2
  exit 1
fi

# Remove mitigation from each software image.
for image_name in "${images[@]}"; do
  rm -f "/var/lib/confluent/public/os/$image_name/scripts/firstboot.d/97-dirty-frag-mitigation.sh"
done


# Remove mitigation drop-in on live nodes if it exists.
pdsh -a "[ -r $REMOTE_REVERT_HELPER ] && /bin/bash $REMOTE_REVERT_HELPER || echo 'Missing shared helper script or execution failed.'" | dshbak -c

# Validation on images
for image_name in "${images[@]}"; do
  image_conf="/var/lib/confluent/public/os/$image_name/scripts/firstboot.d/97-dirty-frag-mitigation.sh"
  if [ -f "$image_conf" ]; then
    echo "${image_name}: 97-dirty-frag-mitigation.sh still present"
  else
    echo "${image_name}: mitigation script removed"
  fi
done

# Validation on live nodes
pdsh -a "[ -r $REMOTE_VALIDATE_HELPER ] && /bin/bash $REMOTE_VALIDATE_HELPER || echo 'Missing shared helper script or execution failed.'" | dshbak -c