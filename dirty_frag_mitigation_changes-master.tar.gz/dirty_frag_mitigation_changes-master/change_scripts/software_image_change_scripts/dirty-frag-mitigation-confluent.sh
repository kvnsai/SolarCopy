#!/bin/bash
## Mitigation for Dirty Frag (CVE-2024-3174) on confluent clusters. 

images=(rhel-9.6-x86_64-compute rhel-9.6-x86_64-login rhel-9.6-x86_64-default )

if [[ $EUID -ne 0 ]]; then
  echo "Error: This script must be run as root or with sudo." >&2
  exit 1
fi

for image_name in "${images[@]}"; do
  # First install script for Modprobe Drop-in 
  cat <<'OUTER' > "/var/lib/confluent/public/os/$image_name/scripts/firstboot.d/97-dirty-frag-mitigation.sh"
#!/bin/bash

cat <<'EOF' > /etc/modprobe.d/dirtyfrag.conf
install esp4 /bin/false
install esp6 /bin/false
install rxrpc /bin/false
EOF
OUTER
  
  chmod +x "/var/lib/confluent/public/os/$image_name/scripts/firstboot.d/97-dirty-frag-mitigation.sh"
done
