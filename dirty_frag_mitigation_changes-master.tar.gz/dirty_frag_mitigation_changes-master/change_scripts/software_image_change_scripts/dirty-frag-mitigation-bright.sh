#!/bin/bash
## Mitigation for Dirty Frag (CVE‑2026‑43284 + CVE‑2026‑43500) on bright clusters. 

images=(bigmem-compute compute gpu-compute-nctk login)

if [[ $EUID -ne 0 ]]; then
  echo "Error: This script must be run as root or with sudo." >&2
  exit 1
fi

# Write the mitigation into each image so the modules cannot be loaded there later.
for image_name in "${images[@]}"; do
  mkdir -p "/cm/images/${image_name}/etc/modprobe.d/"
  printf 'install esp4 /bin/false\ninstall esp6 /bin/false\ninstall rxrpc /bin/false\n' > "/cm/images/${image_name}/etc/modprobe.d/dirtyfrag.conf"
  chmod 0644 "/cm/images/${image_name}/etc/modprobe.d/dirtyfrag.conf"
  echo "Mitigation config written to ${image_name}"
done

