#!/bin/bash
## Mitigation for Dirty Frag (CVE‑2026‑43284 + CVE‑2026‑43500) on confluent clusters. 

images=(rhel-9.6-x86_64-compute  rhel-9.6-x86_64-login rhel-9.6-x86_64-default )

if [[ $EUID -ne 0 ]]; then
  echo "Error: This script must be run as root or with sudo." >&2
  exit 1
fi

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
REMOTE_HELPER="${SCRIPT_DIR}/../live_node_helpers/dirtyfrag_validate_mitigation.sh"

if [[ ! -f "$REMOTE_HELPER" ]]; then
  echo "Error: Helper script not found in shared directory: $REMOTE_HELPER" >&2
  exit 1
fi

# Validation on live nodes
pdsh -a "[ -r \"$REMOTE_HELPER\" ] && /bin/bash \"$REMOTE_HELPER\" || echo 'Missing shared helper: $REMOTE_HELPER or execution failed.'" | dshbak -c



# Validation on images
expected_content=$(cat <<'OUTER'
#!/bin/bash

cat <<'EOF' > /etc/modprobe.d/dirtyfrag.conf
install esp4 /bin/false
install esp6 /bin/false
install rxrpc /bin/false
EOF
OUTER
)

for image_name in "${images[@]}"; do
    image_conf="/var/lib/confluent/public/os/$image_name/scripts/firstboot.d/97-dirty-frag-mitigation.sh"

    [[ -f "$image_conf" ]] || { echo "ERROR: missing file $image_conf"; continue; }
    [[ -x "$image_conf" ]] || { echo "ERROR: not executable $image_conf"; continue; }

    if ! diff -q <(printf '%s\n' "$expected_content") "$image_conf" >/dev/null; then
        echo "ERROR: content mismatch $image_conf"
        continue
    fi
done
