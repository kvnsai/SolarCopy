#!/bin/bash
## Mitigation for Dirty Frag (CVE-2024-3174) on bright clusters. 

images=(bigmem-compute compute gpu-compute-nctk login)

if [[ $EUID -ne 0 ]]; then
  echo "Error: This script must be run as root or with sudo." >&2
  exit 1
fi

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
REMOTE_HELPER="${SCRIPT_DIR}/../live_node_helpers/dirtyfrag_validate_mitigation.sh"

if [[ ! -f "$REMOTE_HELPER" ]]; then
  echo "Error: Helper script not found in shared directory: $REMOTE_HELPER" >&2
  exit 1
fi

# Validation on images
for image_name in "${images[@]}"; do
  image_conf="/cm/images/${image_name}/etc/modprobe.d/dirtyfrag.conf"
  if grep -qF $'install esp4 /bin/false\ninstall esp6 /bin/false\ninstall rxrpc /bin/false' "$image_conf"; then
    echo "${image_name}: dirtyfrag.conf contains the expected install overrides"
  else
    echo "${image_name}: dirtyfrag.conf is missing overrides"
  fi
done

# Validation on live nodes
pdsh -a "[ -r $REMOTE_HELPER ] && /bin/bash $REMOTE_HELPER || echo 'Missing shared helper: $REMOTE_HELPER'" | dshbak -c
