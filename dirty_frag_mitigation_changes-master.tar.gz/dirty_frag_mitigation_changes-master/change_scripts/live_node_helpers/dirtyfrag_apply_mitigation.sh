#!/bin/bash

if lsmod | grep -qE '^(esp4|esp6) '; then
  echo "IPsec-related modules detected; skipping mitigation"
else
  rmmod esp4 esp6 rxrpc 2>/dev/null
  cat > /etc/modprobe.d/dirtyfrag.conf <<'EOF'
install esp4 /bin/false
install esp6 /bin/false
install rxrpc /bin/false
EOF
  echo "No esp4/esp6 modules detected; mitigation applied"
fi
