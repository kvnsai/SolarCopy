#!/bin/bash

if grep -qE '^(esp4|esp6|rxrpc) ' /proc/modules; then
  echo "Affected modules are loaded"
else
  echo "Affected modules are NOT loaded"
fi

if [ -f /etc/modprobe.d/dirtyfrag.conf ]; then
  echo "dirtyfrag.conf is present"
else
  echo "dirtyfrag.conf is missing"
fi
