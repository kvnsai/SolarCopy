#!/bin/bash

if [ -f /etc/modprobe.d/dirtyfrag.conf ]; then
  rm -f /etc/modprobe.d/dirtyfrag.conf
  echo "Removed dirtyfrag.conf"
else
  echo "No dirtyfrag.conf found"
fi
