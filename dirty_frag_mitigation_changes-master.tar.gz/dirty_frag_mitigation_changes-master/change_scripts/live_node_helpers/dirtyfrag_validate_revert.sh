#!/bin/bash

if [ -f /etc/modprobe.d/dirtyfrag.conf ]; then
  echo "Mitigation config still present"
else
  echo "Mitigation config removed"
fi
