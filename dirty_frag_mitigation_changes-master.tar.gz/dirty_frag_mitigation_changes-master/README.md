# DirtyFrag Mitigation Scripts

# Description
Scripts to apply, validate, and revert DirtyFrag (ESP/RxRPC) kernel mitigations on Bright and Confluent clusters.

- No reboot required.
- Blocks `esp4`, `esp6`, `rxrpc` via modprobe.
- Supports live nodes and software images.

# How to implement on systems
- Review the customer comms initial message `Initial_msg.txt`.
  - Ensure the customer has already received sufficient information / consider providing further info as according to this message.
  - Ensure the customer has agreed to the change and you have positively confirmed a scheduled time for this change with the customer.
- Review the change request template `dirty_frag_mitigation_change_request.md`.
- Ensure you copy this repository in its entirity to a cluster wide shared filesystem area before running as directed in the change template.
- Apply mitigations on system as according to the customer's agreed schedule:
  - When applying mitigations, apply as directed by the change template and scripts ensuring you modify the software image names where required under `software_image_change_scripts` and `validation`.
  - If applying mitigations to an individual node, you may wish to apply these directly with `live_node_helpers` scripts directly.

## Repository Layout

```txt
dirty_frag_mitigation_changes
├── README.md
├── change_request_templates
│   └── dirty_frag_mitigation_change_request.md
├── change_scripts
│   ├── live_node_helpers
│   │   ├── dirtyfrag_apply_mitigation.sh
│   │   ├── dirtyfrag_revert_mitigation.sh
│   │   ├── dirtyfrag_validate_mitigation.sh
│   │   └── dirtyfrag_validate_revert.sh
│   ├── live_nodes_change_scripts
│   │   ├── dirty-frag-mitigation-bright.sh
│   │   └── dirty-frag-mitigation-confluent.sh
│   ├── revert_change_scripts
│   │   ├── dirty-frag-mitigation-bright.sh
│   │   └── dirty-frag-mitigation-confluent.sh
│   ├── software_image_change_scripts
│   │   ├── dirty-frag-mitigation-bright.sh
│   │   └── dirty-frag-mitigation-confluent.sh
│   ├── validation
│       ├── dirty-frag-mitigation-bright.sh
│       └── dirty-frag-mitigation-confluent.sh
└── customer_comms
    └── Initial_msg.txt
